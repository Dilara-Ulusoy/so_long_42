/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_map.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dakcakoc <dakcakoc@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/02 15:32:40 by dakcakoc          #+#    #+#             */
/*   Updated: 2024/09/02 16:51:21 by dakcakoc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	count_elements(t_game *game)
{
	int	y;
	int	x;

	game->player_count = 0;
	game->exit_count = 0;
	game->collectible_count = 0;
	y = 0;
	while (y < game->map_height)
	{
		x = 0;
		while (x < game->map_width)
		{
			if (game->map[y][x] == 'P')
				game->player_count++;
			else if (game->map[y][x] == 'E')
				game->exit_count++;
			else if (game->map[y][x] == 'C')
				game->collectible_count++;
			x++;
		}
		y++;
	}
}

void	validate_counts(t_game *game)
{
	if (game->player_count != 1)
	{
		ft_putstr("Error: Player count is not exactly 1.\n");
		exit(1);
	}
	if (game->exit_count != 1)
	{
		ft_putstr("Error: Exit count is not exactly 1.\n");
		exit(1);
	}
	if (game->collectible_count < 1)
	{
		ft_putstr("Error: Collectible count is not enough.\n");
		exit(1);
	}
}

char	**copy_map(t_game *game)
{
	char	**copy;
	int		i;

	copy = malloc(sizeof(char *) * (game->map_height + 1));
	if (!copy)
	{
		ft_putstr("Error: Memory allocation failed.");
		exit(1);
	}
	i = 0;
	while (i < game->map_height)
	{
		copy[i] = strdup(game->map[i]);
		if (!copy[i])
		{
			free_allocated_memory(copy, i);
		}
		i++;
	}
	copy[game->map_height] = NULL;
	return (copy);
}

void	check_map_validity(t_game *game)
{
	char	**map_copy;

	check_map_exists(game);
	count_elements(game);
	validate_counts(game);
	map_copy = copy_map(game);
	check_player_can_reach_exit(game, map_copy);
}

bool	flood_fill(t_game *game, char **map_copy, int x, int y)
{
	if (x < 0 || x >= game->map_height || y < 0 || y >= game->map_width)
		return (false);
	if (map_copy[x][y] == '1' || map_copy[x][y] == 'V')
		return (false);
	if (map_copy[x][y] == 'E')
		return (true);
	map_copy[x][y] = 'V';
	if (flood_fill(game, map_copy, x - 1, y))
		return (true);
	if (flood_fill(game, map_copy, x + 1, y))
		return (true);
	if (flood_fill(game, map_copy, x, y - 1))
		return (true);
	if (flood_fill(game, map_copy, x, y + 1))
		return (true);
	return (false);
}
/*
// Flood fill function checks if the player can reach the exit.
// It returns true if the player can reach the exit, false otherwise.
// It uses a copy of the map to mark visited cells.
// x and y are the current coordinates of player in the map.


bool	flood_fill(t_game *game, char **map_copy, int x, int y)
{
	if (x < 0 || x >= game->map_height || y < 0 || y >= game->map_width)
		return (false); // Out of map bounds
	if (map_copy[x][y] == '1' || map_copy[x][y] == 'V')
		return (false); // Hit a wall or visited cell
	if (map_copy[x][y] == 'E')
		return (true); // Found the exit

	map_copy[x][y] = 'V'; // Mark the current position as visited
	if (flood_fill(game, map_copy, x - 1, y)) // Check up
		return (true);
	if (flood_fill(game, map_copy, x + 1, y)) // Check down
		return (true);
	if (flood_fill(game, map_copy, x, y - 1)) // Check left
		return (true);
	if (flood_fill(game, map_copy, x, y + 1)) // Check right
		return (true);
	// If none of the directions work, return false
	return (false);
}
*/
