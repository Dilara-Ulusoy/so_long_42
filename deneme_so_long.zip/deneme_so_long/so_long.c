/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dakcakoc <dakcakoc@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/02 21:03:18 by dakcakoc          #+#    #+#             */
/*   Updated: 2024/09/02 23:23:52 by dakcakoc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	setup_window(t_game *game)
{
	game->window_width = game->map_width * TILE_SIZE;
	game->window_height = game->map_height * TILE_SIZE;
}

int	main(int argc, char **argv)
{
	t_game	game;

	if (argc != 2)
	{
		ft_putstr("Usage: ./so_long <map_file>\n");
		return (1);
	}
	game.mlx_ptr = mlx_init();
	load_map(&game, argv[1]);
	check_if_map_is_enclosed(&game);
	check_map_exists(&game);
	init_player_collectibles_moves(&game);
	check_map_validity(&game);
	setup_window(&game);
	game.win = mlx_new_window(game.mlx_ptr,
			game.window_width, game.window_height, "SO_LONG");
	load_images(&game);
	mlx_key_hook(game.win, handle_key_press, &game);
	render_map(&game);
	mlx_loop(game.mlx_ptr);
	return (0);
}
