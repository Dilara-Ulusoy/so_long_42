/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_map_1.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dakcakoc <dakcakoc@student.hive.fi>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/02 15:28:01 by dakcakoc          #+#    #+#             */
/*   Updated: 2024/09/02 22:50:25 by dakcakoc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

bool	is_map_enclosed(t_game *game)
{
	int	y;
	int	x;

	y = 0;
	while (y < game->map_height)
	{
		x = 0;
		while (x < game->map_width)
		{
			if (y == 0 || y == game->map_height - 1
				|| x == 0 || x == game->map_width - 1)
			{
				if (game->map[y][x] != '1')
				{
					return (false);
				}
			}
			x++;
		}
		y++;
	}
	return (true);
}

void	check_player_can_reach_exit(t_game *game, char **map_copy)
{
	int	i;

	if (flood_fill(game, map_copy, game->player_x, game->player_y) == false)
	{
		ft_putstr("Error: Map is not valid. Player cannot reach the exit.\n");
		i = 0;
		while (i < game->map_height)
		{
			free(map_copy[i]);
			i++;
		}
		free(map_copy);
		free_game_map(game);
		exit(1);
	}
}

void	check_if_map_is_enclosed(t_game *game)
{
	if (is_map_enclosed(game) == false)
	{
		ft_putstr("Error: Map is not valid. Map is not enclosed by walls.\n");
		exit(1);
	}
}

void	check_map_exists(t_game *game)
{
	if (!game->map || game->map_height <= 0 || game->map_width <= 0)
	{
		ft_putstr("Error: No map provided or invalid map dimensions.\n");
		exit(1);
	}
}

void	check_ber_extension(const char *filename)
{
	const char	*ber;

	ber = ft_strrchr(filename, '.ber');
	if (!ber)
	{
		ft_putstr("Error: Invalid file extension.Provide a .ber file.\n");
		exit(1);
	}
}
